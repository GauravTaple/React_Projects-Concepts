import './App.css';
import State from './components/State';

function App() {
  return (
    <div className="App">
    <h1>Concepts</h1>
    {/* <Controlled/>
    <Uncontrolled/>
    <Useref/>
    <Usememo/>
    <Usecallback/>
    <Useeffect/> */}
    {/* <Usereducer/> */}
    {/* <AxiosComp/> */}
    {/* <ChangeCase/> */}
    <State/>
  </div>
  );
}

export default App;
