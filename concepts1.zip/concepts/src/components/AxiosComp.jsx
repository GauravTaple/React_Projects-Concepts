import React, { useEffect, useState } from 'react';
import axios from './axiosApi';

const API = "https://jsonplaceholder.typicode.com";

export default function AxiosComp() {
  const [userData,setuserData] = useState([]);
  const [error,setError] = useState([]);

//------------------------------------------------1st Way----------------------------------------------------------------------------------
//----------- get the data using promise .then concept --------------------------
  const getData = (url)=>{
    axios.get(url)
    .then((response)=>{
      setuserData(response.data);
    })
    .catch((error)=>{
      console.log(error,'error---')
      setError(error.message)
    })
  }

  useEffect(()=>{
    getData(`${API}/users`);
  },[])




//-------------------------------------------2nd Way-----------------------------------------------------------------------------------------
//----------- get the data using promise async & await concept and using baseURL (axiosApi.jsx file)------------------
  // async function getData (){
  //   try{
  //     const resp = await axios.get('/users')
  //     setuserData(resp.data)
  //   }catch(error){
  //     console.log(error,'error');
  //     setError(error.message)
  //   }
  // }

  // useEffect(()=>{
  //   getData();
  // },[])

  return (
    <div>
      <h1>Axios</h1>
      {error !== '' && <h2>{error}</h2>}
      <div>{userData.map((data,index)=>{ 
        return <h3 key={data.id} >{data.name} :- {data.website} :- {data.phone}</h3>
      })}
      </div>
    </div>
  )
}
