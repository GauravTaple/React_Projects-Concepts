export default function BasicDatePicker() {
    const handleSubmit = () => {
      console.log("pressed");
    };
    return (
      <>
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DemoContainer components={["DatePicker"]}>
            <DatePicker label="Basic date picker" />
          </DemoContainer>
        </LocalizationProvider>
  
        <button onClick={handleSubmit}> Submit</button>
      </>
    );
  }