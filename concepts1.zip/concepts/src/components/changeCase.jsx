import * as changeCase from "change-case";
import React, { useEffect, useState } from "react";

export default function ChangeCase(){
  const [isCase,setCase] = useState('');
  console.log(isCase,'isCase');
  const [isValue,setIsValue]=useState(false);
  console.log(isValue,'isValue');
  const [prevValue, setPrevValue] = useState("");
//   console.log(prevValue,'prevValue');

    const data = (isCase) => {
    const camelCaseString = changeCase.capitalCase(isCase)
    console.log(camelCaseString,'camel');
    setCase(camelCaseString);                                                                                                               
    setIsValue(true);
    setPrevValue(isCase);
    }

    const onChange = (e) =>{
        setCase(e.target.value);
        setIsValue(false);
    }

    useEffect(()=>{
        if(isValue){
            setCase(prevValue);
        }
    },[isValue,prevValue]);
    
    return(                                                                                                 
        <>
        <input type="text" onChange={(e)=> onChange(e)} placeholder="Type a string"/>
        <button onClick={()=> data(isCase)}>ChangeCase</button>
        {isValue ? (<h1>{isCase}</h1>)
        :(<h1>{prevValue}</h1>)
        }        
        </>

    )
}