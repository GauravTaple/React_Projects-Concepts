import { useState } from "react";

function Controlled() {
  const [name, setName] = useState();

  const handleChange = (e) => {
    setName(e.target.value);
  };
  return (
    <div className="App">
      <h1>React form with controlled components</h1>
      <form>
        <label>Name:</label>
        <input type="text" value={name} onChange={handleChange} />
      </form>
    </div>
  );
}

export default Controlled;
