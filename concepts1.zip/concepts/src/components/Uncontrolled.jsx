import { useRef } from "react";

function Uncontrolled() {
  const refObject = useRef();

  function handleSubmit(e) {
    e.preventDefault();
    console.log(refObject.current.value);
  }
  return (
    <>
      <h2>React form with uncontrolled components</h2>
      <form onSubmit={handleSubmit}>
        <label>Name:</label>
        <input type="text" ref={refObject} />
        <button>Submit</button>
      </form>
    </>
  );
}

export default Uncontrolled;
