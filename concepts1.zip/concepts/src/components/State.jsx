import React, { Component } from 'react'

class State extends Component {
    constructor(props){
        super(props);
        this.state = {
            count:5
        }
    }

    increment = () => {
        this.setState((prevState)=>({
            count:prevState.count+5
        }));
    }

    decrement = () =>{
        this.setState((prevState)=>({
            count:prevState.count-1
        }))
    }

    multiplication = () => {
        this.setState((prevState)=>({
            count:prevState.count*this.state.count
        }));
    }

  render() {
    return (
      <div>
        <h1>The Current Count is:{this.state.count}</h1>
        <button onClick={this.increment}>Increment</button>
        <button onClick={this.decrement}>Decrement</button>
        <button onClick={this.multiplication}>Multiplication</button>
      </div>
    )
  }
}

export default State
