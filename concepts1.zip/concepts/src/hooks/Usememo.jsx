import { useMemo, useState } from "react";

function Usememo(){
    const [add, setAdd] = useState(0);
    const [subtract, setSubtract] = useState(50);

    const Divisional = useMemo( function Division (){
        console.log("**********************");
        return (add / 2);
    },[add])

  

    return(
        <div>
        <h1>UseMemo Hook</h1>
        {Divisional}
        <br/>
        <button onClick={()=>setAdd(add+1)}>Add</button>
        <span> {add}</span>
        <br/>
        <button onClick={()=>setSubtract(subtract-1)}>Subtract</button>
        <span> {subtract}</span>
        </div>
    )
}

export default Usememo;