import React, { memo } from 'react';

function ChildA({Learning}) {
    console.log('Child Component Called');
  return (
    <div></div>
  )
}

export default memo(ChildA);