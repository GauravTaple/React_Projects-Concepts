import React, { useEffect, useState } from 'react'

function Useeffect() {
    const [click,setClick]=useState(0);
    const [update,setUpdate]=useState('Ram');

    useEffect(()=>{
        console.log("UseEffect Called");
    },[click])



  return (
    <>
    <h1>UseEffect</h1>

    <h3>Button pressed {click} times</h3>
    <button onClick={()=>{setClick(click+1)}}>Click</button>

    <h3>{update}</h3>
    <button onClick={()=>{setUpdate('Siya')}}>update</button>
    </>
  )
}

export default Useeffect