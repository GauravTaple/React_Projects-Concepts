import React, { useCallback, useState } from 'react';
import ChildA from './ChildA';

function Usecallback() {
    const [add,setAdd]= useState(0);
    const [count,setCount]= useState(0);

    const Learn = useCallback(()=>{
        console.log("Learn called");
    },[count])

  return (
    <>
    <h1>UseCallback</h1>
    <ChildA Learning={Learn} />
    <h3>{add}</h3>
    <button onClick={()=>setAdd(add+2)}>Add</button>

    <h3>{count}</h3>
    <button onClick={()=>setCount(count+1*10)}>Count</button>
    </>
  )
}

export default Usecallback