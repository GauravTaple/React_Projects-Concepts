import { useRef, useState } from "react";

function Useref() {
  const refElement = useRef();
  const [name,setName] = useState();

  const handleSubmit=(e)=>{
    refElement.current.style.color='blue'
    // refElement.current.focus();
  }

  const handleReset = (e)=>{
    setName('');
    refElement.current.focus();
  }
  return (
    <div>
        <h1>UseRef Hook</h1>
        <input ref={refElement} type='text' value={name} onChange={(e)=>setName(e.target.value)}/>
        <button onClick={handleSubmit}>Submit</button>
        <button onClick={handleReset}>Reset</button>
    </div>
  )
}

export default Useref;